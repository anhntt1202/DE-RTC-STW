a = {1: 'hello',
     2: 'co gi ko',
     3: 'khong co a',
     4: 'u'}

def dummy(d):
    d[2] = 'deo'

dummy(a)
print(a)

z = 64
def dummy2(i):
    i = 94
dummy2(z)
print(z)